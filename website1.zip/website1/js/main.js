(function($) {
  "use strict";

  jQuery(document).ready(function(){

        /* --------------------------------------------------------
            Mega Menu Column Support
        --------------------------------------------------------- */
        // $('.mega-menu').each(function(){
        //     if($(this).children('li').length){
        //         var ulChildren = $(this).children('li').length;
        //         $(this).addClass('column-'+ulChildren)
        //     }
        // });
        

        /* Remove Attribute( href ) from sub-menu title in mega-menu */
        // $('.mega-menu > li > a').removeAttr('href');


        /* Property not showing if sub-menu title is blank in mega-menu */
        // If possible then do it, or you can ignore
        // $().();


        /* --------------------------------------------------------
            Portfolio Active
        --------------------------------------------------------- */
        // $('.portfolio-active').imagesLoaded( function() {

        //     // filter items on button click
        //     $('.portfolio-filter').on( 'click', 'li', function() {
        //         var filterValue = $(this).attr('data-filter');
        //         $portfolioFilter.isotope({ filter: filterValue });
        //     });

        //     // init Isotope
        //     var $portfolioFilter = $('.portfolio-active').isotope({
        //         itemSelector: '.portfolio-item',
        //         percentPosition: true,
        //         masonry: {
        //             // use outer width of grid-sizer for columnWidth
        //             columnWidth: '.portfolio-item'
        //         }
        //     })

        // });


        /* --------------------------------------------------------
            MagnificPopup Active 
        --------------------------------------------------------- */


        // $('.testpopup').magnificPopup({
        //     type: 'image',
        //     gallery: {
        //         enabled: true
        //     }
        // });


        // $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
        //   disableOn: 700,
        //   type: 'iframe',
        //   mainClass: 'mfp-fade',
        //   removalDelay: 160,
        //   preloader: false,

        //   fixedContentPos: false
        // }); 



        // $('.image-popup-no-margins').magnificPopup({
        //     type: 'image',
        //     closeOnContentClick: true,
        //     closeBtnInside: false,
        //     fixedContentPos: true,
        //     mainClass: 'mfp-no-margins mfp-with-zoom', 
        //     image: {
        //         verticalFit: true
        //     },
        //     zoom: {
        //         enabled: true,
        //         duration: 300 
        //     }
        // });


        /* --------------------------------------------------------
            Facebook Like Button
        --------------------------------------------------------- */


        /* --------------------------------------------------------
            Abcdefghijklmnopqrstuvwxyz
        --------------------------------------------------------- */
        $('.slide-active').slick({
            dots: false,
            infinite: false,
            // autoplay: true,
            // autoplaySpeed: 5000,
            speed: 300,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            prevArrow: '<button class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button class="slick-next"><i class="fas fa-chevron-right"></i></button>',
        });

        /* --------------------------------------------------------
            Abcdefghijklmnopqrstuvwxyz
        --------------------------------------------------------- */
        


        /* --------------------------------------------------------
            Abcdefghijklmnopqrstuvwxyz
        --------------------------------------------------------- */








  });
  
})(jQuery);